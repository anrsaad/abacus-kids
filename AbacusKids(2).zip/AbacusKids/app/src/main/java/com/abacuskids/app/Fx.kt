package com.abacuskids.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

object C {
    val Sky1 = Color(0xFF7FD6FF)
    val Sky2 = Color(0xFFEFFAFF)
    val Red = Color(0xFFE53935)
    val Yellow = Color(0xFFFFC107)
    val Blue = Color(0xFF1E88E5)
    val Green = Color(0xFF43A047)
    val Orange = Color(0xFFFB8C00)
    val Purple = Color(0xFF8E24AA)
    val Wood = Color(0xFF8A4F14)
    val Ink = Color(0xFF3E2723)
}

fun starPath(cx: Float, cy: Float, outer: Float): Path {
    val inner = outer * 0.45f
    val p = Path()
    for (i in 0 until 10) {
        val r = if (i % 2 == 0) outer else inner
        val a = -PI / 2 + i * PI / 5
        val x = cx + (r * cos(a)).toFloat()
        val y = cy + (r * sin(a)).toFloat()
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    return p
}

@Composable
fun StarIcon(sz: Dp, color: Color = C.Yellow, modifier: Modifier = Modifier) {
    Canvas(modifier.size(sz)) {
        val c = this.size.width / 2f
        drawPath(starPath(c, c * 1.05f, c * 0.95f), color)
        drawPath(starPath(c, c * 1.05f, c * 0.95f), Color(0x55000000), style = Stroke(width = c * 0.08f))
    }
}

private class Particle(val x: Float, val speed: Float, val r: Float, val color: Color, val sway: Float)

@Composable
fun Confetti(modifier: Modifier = Modifier) {
    val t = remember { Animatable(0f) }
    LaunchedEffect(Unit) { t.animateTo(1f, tween(2400, easing = LinearEasing)) }
    val palette = listOf(C.Red, C.Yellow, C.Blue, C.Green, C.Orange, C.Purple)
    val parts = remember {
        List(34) {
            Particle(Random.nextFloat(), 0.6f + Random.nextFloat() * 0.8f, 0.012f + Random.nextFloat() * 0.02f,
                palette.random(), Random.nextFloat() * 6f)
        }
    }
    Canvas(modifier.fillMaxSize()) {
        val p = t.value
        for (pt in parts) {
            val y = (-0.1f + p * pt.speed * 1.3f) * size.height
            val x = (pt.x + 0.03f * sin(pt.sway + p * 8f)) * size.width
            if (y < size.height) drawPath(starPath(x, y, pt.r * size.width + 8f), pt.color)
        }
    }
}

@Composable
fun Mascot(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "mascot")
    val dy by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "dy",
    )
    Canvas(modifier.size(120.dp)) {
        val w = size.width
        translate(top = -dy * w * 0.07f) {
            val c = Offset(w / 2, w * 0.46f)
            drawCircle(Color(0xFFFFB300), w * 0.4f, c)
            drawCircle(Color(0xFFFFD54F), w * 0.34f, c)
            // eyes
            listOf(-1f, 1f).forEach { s ->
                val e = Offset(c.x + s * w * 0.14f, c.y - w * 0.05f)
                drawCircle(Color.White, w * 0.09f, e)
                drawCircle(C.Ink, w * 0.055f, e + Offset(0f, w * 0.01f))
                drawCircle(Color.White, w * 0.018f, e + Offset(-w * 0.015f, -w * 0.01f))
                drawCircle(Color(0x55FF5252), w * 0.06f, Offset(c.x + s * w * 0.24f, c.y + w * 0.1f))
            }
            drawArc(
                C.Ink, 25f, 130f, false,
                topLeft = Offset(c.x - w * 0.14f, c.y + w * 0.0f), size = Size(w * 0.28f, w * 0.2f),
                style = Stroke(width = w * 0.035f, cap = StrokeCap.Round),
            )
            // little beads
            val cols = listOf(C.Red, C.Yellow, C.Blue, C.Green, C.Orange)
            cols.forEachIndexed { i, col ->
                drawCircle(col, w * 0.055f, Offset(w * (0.2f + i * 0.15f), w * 0.93f))
            }
        }
    }
}
