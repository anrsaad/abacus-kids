package com.abacuskids.app

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.util.Locale

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "abacus_prefs")

object K {
    val LANG = stringPreferencesKey("lang")
    val SOUND = booleanPreferencesKey("sound")
    val LEVEL = intPreferencesKey("level")
    val GAMES = intPreferencesKey("games")
    val CORRECT = intPreferencesKey("correct")
    val CHECKS = intPreferencesKey("checks")
    val POINTS = intPreferencesKey("points")
    val BEST_MATH = intPreferencesKey("best_math")
    val BEST_TIME = intPreferencesKey("best_time")
    val GOLD = intPreferencesKey("gold")
    val SILVER = intPreferencesKey("silver")
    val BRONZE = intPreferencesKey("bronze")
}

data class Prefs(
    val lang: String, val sound: Boolean, val level: Int,
    val games: Int, val correct: Int, val checks: Int, val points: Int,
    val bestMath: Int, val bestTime: Int, val gold: Int, val silver: Int, val bronze: Int,
)

fun MutablePreferences.inc(k: Preferences.Key<Int>, by: Int = 1) {
    this[k] = (this[k] ?: 0) + by
}

class PrefsRepo(private val ctx: Context) {
    val flow: Flow<Prefs> = ctx.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { p ->
            Prefs(
                lang = p[K.LANG] ?: if (Locale.getDefault().language == "ar") "ar" else "fr",
                sound = p[K.SOUND] ?: true,
                level = (p[K.LEVEL] ?: 0).coerceIn(0, 2),
                games = p[K.GAMES] ?: 0, correct = p[K.CORRECT] ?: 0,
                checks = p[K.CHECKS] ?: 0, points = p[K.POINTS] ?: 0,
                bestMath = p[K.BEST_MATH] ?: 0, bestTime = p[K.BEST_TIME] ?: 0,
                gold = p[K.GOLD] ?: 0, silver = p[K.SILVER] ?: 0, bronze = p[K.BRONZE] ?: 0,
            )
        }

    suspend fun edit(block: (MutablePreferences) -> Unit) {
        try { ctx.dataStore.edit { block(it) } } catch (_: Exception) { }
    }

    suspend fun resetStats() {
        try {
            ctx.dataStore.edit { p ->
                listOf(K.GAMES, K.CORRECT, K.CHECKS, K.POINTS, K.BEST_MATH, K.BEST_TIME, K.GOLD, K.SILVER, K.BRONZE)
                    .forEach { p.remove(it) }
            }
        } catch (_: Exception) { }
    }
}
