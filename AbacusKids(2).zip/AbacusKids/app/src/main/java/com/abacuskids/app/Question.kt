package com.abacuskids.app

import kotlin.random.Random

enum class QKind { ADD, SUB, ADD3, MISS_ADD, MISS_SUB }

data class Question(val text: String, val answer: Int, val kind: QKind, val nums: List<Int>)

/** Generates random questions for a max value (10 / 50 / 100), avoiding recent repeats. */
class QuestionGenerator {
    private val recent = ArrayDeque<String>()

    fun next(max: Int): Question {
        var q = make(max)
        var tries = 0
        while (recent.contains(q.text) && tries < 50) { q = make(max); tries++ }
        recent.addLast(q.text)
        if (recent.size > 15) recent.removeFirst()
        return q
    }

    private fun make(max: Int): Question {
        return when (QKind.values().random()) {
            QKind.ADD -> {
                val r = Random.nextInt(2, max + 1)
                val a = Random.nextInt(1, r)
                val b = r - a
                Question("$a + $b = ?", r, QKind.ADD, listOf(a, b))
            }
            QKind.SUB -> {
                val a = Random.nextInt(2, max + 1)
                val b = Random.nextInt(1, a)
                Question("$a - $b = ?", a - b, QKind.SUB, listOf(a, b))
            }
            QKind.ADD3 -> {
                val r = Random.nextInt(3, max + 1)
                val a = Random.nextInt(1, r - 1)
                val b = Random.nextInt(1, r - a)
                val c = r - a - b
                Question("$a + $b + $c = ?", r, QKind.ADD3, listOf(a, b, c))
            }
            QKind.MISS_ADD -> {
                val c = Random.nextInt(2, max + 1)
                val a = Random.nextInt(1, c)
                Question("$a + ? = $c", c - a, QKind.MISS_ADD, listOf(a, c))
            }
            QKind.MISS_SUB -> {
                val a = Random.nextInt(2, max + 1)
                val x = Random.nextInt(1, a)
                val c = a - x
                Question("$a - ? = $c", x, QKind.MISS_SUB, listOf(a, c))
            }
        }
    }
}
