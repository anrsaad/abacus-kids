package com.abacuskids.app

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Tiny synthesized sound effects (no audio files needed, fully offline). */
object Sound {
    @Volatile var enabled = true
    private val pool = Executors.newCachedThreadPool()
    private const val SR = 22050

    /** notes: list of (frequencyHz, durationMs); frequency 0 = silence. */
    private fun play(notes: List<Pair<Int, Int>>, volume: Double = 0.45) {
        if (!enabled) return
        pool.execute {
            try {
                val total = notes.sumOf { SR * it.second / 1000 }
                val buf = ShortArray(total)
                var pos = 0
                for ((f, ms) in notes) {
                    val n = SR * ms / 1000
                    for (i in 0 until n) {
                        val env = max(0.0, min(1.0, min(i / (SR * 0.005), (n - i) / (SR * 0.03))))
                        val v = if (f == 0) 0.0 else sin(2 * PI * f * i / SR) * env * volume
                        buf[pos++] = (v * Short.MAX_VALUE).toInt().toShort()
                    }
                }
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                    )
                    .setBufferSizeInBytes(buf.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(buf, 0, buf.size)
                track.play()
                Thread.sleep(total * 1000L / SR + 120)
                track.release()
            } catch (_: Throwable) { }
        }
    }

    fun tick() = play(listOf(1400 to 18, 900 to 22), 0.35)
    fun click() = play(listOf(700 to 35), 0.3)
    fun correct() = play(listOf(523 to 110, 659 to 110, 784 to 110, 1047 to 260))
    fun wrong() = play(listOf(330 to 160, 262 to 260), 0.4)
    fun fanfare() = play(listOf(523 to 130, 523 to 130, 523 to 130, 659 to 200, 784 to 130, 659 to 130, 784 to 400))
}
