package com.abacuskids.app

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

// Row 1 yellow (units), row 2 green (tens), then red, blue, orange...
private val rowColors = listOf(
    Color(0xFFFFC107), Color(0xFF43A047), Color(0xFFE53935), Color(0xFF1E88E5), Color(0xFFFB8C00),
)
private val rowLabels = listOf("1", "10", "100", "1K", "10K", "100K", "1M", "10M", "100M", "1B")

private class Geo(w: Float, h: Float) {
    val ft = min(w, h) * 0.045f
    val x0 = ft
    val y0 = ft
    val x1 = w - ft
    val y1 = h - ft
    val rowH = (y1 - y0) / 10f
    val labelW = (x1 - x0) * 0.09f
    val tl = x0 + ft * 0.8f + labelW
    val tw = (x1 - x0) - ft * 1.6f - labelW
    val bw = tw / 13f
    val gap = 3f * bw
    fun cx(i: Int, p: Float) = tl + i * bw + bw / 2f + gap * p
    fun cy(r: Int) = y0 + r * rowH + rowH / 2f
}

private fun hit(g: Geo, counts: List<Int>, o: Offset): Pair<Int, Int>? {
    if (o.y < g.y0 || o.y > g.y1) return null
    val r = ((o.y - g.y0) / g.rowH).toInt().coerceIn(0, 9)
    var best = 0
    var bd = Float.MAX_VALUE
    for (i in 0 until 10) {
        val p = if (i >= 10 - counts[r]) 1f else 0f
        val d = abs(o.x - g.cx(i, p))
        if (d < bd) { bd = d; best = i }
    }
    return r to best
}

/**
 * Interactive abacus: 10 rows x 10 beads. beads[row] = number of beads on the right side.
 * Tap or drag a bead: it pushes its neighbours like a real wooden abacus.
 */
@Composable
fun Abacus(beads: List<Int>, onSet: (row: Int, count: Int) -> Unit, modifier: Modifier = Modifier) {
    val progress = List(100) { idx ->
        val r = idx / 10
        val i = idx % 10
        val onRight = i >= 10 - beads[r]
        animateFloatAsState(
            targetValue = if (onRight) 1f else 0f,
            animationSpec = spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessMediumLow),
            label = "bead",
        )
    }
    val counts = rememberUpdatedState(beads)
    val setter = rememberUpdatedState(onSet)

    Canvas(
        modifier
            .pointerInput(Unit) {
                detectTapGestures { off ->
                    val g = Geo(size.width.toFloat(), size.height.toFloat())
                    val h = hit(g, counts.value, off) ?: return@detectTapGestures
                    val (r, i) = h
                    val onRight = i >= 10 - counts.value[r]
                    setter.value(r, if (onRight) 9 - i else 10 - i)
                }
            }
            .pointerInput(Unit) {
                var row = -1
                var bead = -1
                detectDragGestures(
                    onDragStart = { off ->
                        val g = Geo(size.width.toFloat(), size.height.toFloat())
                        val h = hit(g, counts.value, off)
                        row = h?.first ?: -1
                        bead = h?.second ?: -1
                    },
                    onDragEnd = { row = -1 },
                    onDragCancel = { row = -1 },
                ) { change, _ ->
                    if (row >= 0) {
                        change.consume()
                        val g = Geo(size.width.toFloat(), size.height.toFloat())
                        val mid = g.cx(bead, 0f) + g.gap / 2f
                        val newCount = if (change.position.x > mid) 10 - bead else 9 - bead
                        if (newCount != counts.value[row]) setter.value(row, newCount)
                    }
                }
            }
    ) {
        val g = Geo(size.width, size.height)
        // wooden frame
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFC77D2E), Color(0xFF8A4F14))),
            cornerRadius = CornerRadius(g.ft * 1.2f),
        )
        drawRoundRect(
            color = Color(0xFFFFEFC7),
            topLeft = Offset(g.x0, g.y0),
            size = Size(g.x1 - g.x0, g.y1 - g.y0),
            cornerRadius = CornerRadius(g.ft * 0.5f),
        )
        val rad = min(g.bw, g.rowH) * 0.47f
        for (r in 0 until 10) {
            val y = g.cy(r)
            drawLine(
                color = Color(0xFF8D6E63),
                start = Offset(g.tl - g.ft * 0.2f, y),
                end = Offset(g.tl + g.tw + g.ft * 0.2f, y),
                strokeWidth = max(2f, g.rowH * 0.07f),
                cap = StrokeCap.Round,
            )
            val col = rowColors[r % 5]
            // place-value label (1, 10, 100...)
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.rgb(
                    (col.red * 190).toInt(), (col.green * 190).toInt(), (col.blue * 190).toInt()
                )
                textAlign = android.graphics.Paint.Align.CENTER
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                textSize = min(g.rowH * 0.5f, g.labelW * 0.42f)
            }
            drawContext.canvas.nativeCanvas.drawText(
                rowLabels[r], g.x0 + g.ft * 0.8f + g.labelW / 2f, y + paint.textSize * 0.35f, paint
            )
            for (i in 0 until 10) {
                val c = Offset(g.cx(i, progress[r * 10 + i].value), y)
                drawCircle(col, rad, c)
                drawCircle(Color.Black.copy(alpha = 0.25f), rad, c, style = Stroke(width = rad * 0.1f))
                drawCircle(Color.White.copy(alpha = 0.5f), rad * 0.25f, c + Offset(-rad * 0.3f, -rad * 0.35f))
            }
        }
    }
}
