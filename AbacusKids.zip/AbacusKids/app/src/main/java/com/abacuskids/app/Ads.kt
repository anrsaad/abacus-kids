package com.abacuskids.app

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ApplicationInfo
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/**
 * AdMob wrapper, configured for a children's app:
 * child-directed treatment, under-age-of-consent, max content rating G, no personalised ads.
 * Debug builds use Google's official TEST ad units; release builds use the real ones.
 */
object Ads {
    private const val BANNER_REAL = "ca-app-pub-2933009400126835/7334841678"
    private const val INTERSTITIAL_REAL = "ca-app-pub-2933009400126835/5876475688"
    private const val BANNER_TEST = "ca-app-pub-3940256099942544/6300978111"
    private const val INTERSTITIAL_TEST = "ca-app-pub-3940256099942544/1033173712"

    private const val EVERY_N_GAMES = 2
    private const val MIN_GAP_MS = 3 * 60 * 1000L

    private var appCtx: Context? = null
    private var interstitial: InterstitialAd? = null
    private var loading = false
    private var gamesSinceAd = 0
    private var lastShown = 0L
    private val main = Handler(Looper.getMainLooper())

    private fun isDebug(ctx: Context) = (ctx.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
    fun bannerId(ctx: Context) = if (isDebug(ctx)) BANNER_TEST else BANNER_REAL
    private fun interstitialId(ctx: Context) = if (isDebug(ctx)) INTERSTITIAL_TEST else INTERSTITIAL_REAL

    fun init(context: Context) {
        val app = context.applicationContext
        appCtx = app
        MobileAds.setRequestConfiguration(
            RequestConfiguration.Builder()
                .setTagForChildDirectedTreatment(RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE)
                .setTagForUnderAgeOfConsent(RequestConfiguration.TAG_FOR_UNDER_AGE_OF_CONSENT_TRUE)
                .setMaxAdContentRating(RequestConfiguration.MAX_AD_CONTENT_RATING_G)
                .build()
        )
        Thread {
            try {
                MobileAds.initialize(app) { main.post { preload() } }
            } catch (_: Throwable) { }
        }.start()
    }

    private fun preload() {
        val ctx = appCtx ?: return
        if (loading || interstitial != null) return
        loading = true
        try {
            InterstitialAd.load(ctx, interstitialId(ctx), AdRequest.Builder().build(),
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad; loading = false }
                    override fun onAdFailedToLoad(error: LoadAdError) { interstitial = null; loading = false }
                })
        } catch (_: Throwable) { loading = false }
    }

    fun onGameFinished() { gamesSinceAd++ }

    /** Shows the interstitial only at a natural break: every 2nd finished game, at most every 3 minutes. */
    fun showIfDue(activity: Activity?) {
        val ad = interstitial ?: run { preload(); return }
        if (activity == null) return
        val now = System.currentTimeMillis()
        if (gamesSinceAd < EVERY_N_GAMES || now - lastShown < MIN_GAP_MS) return
        // small delay so the tap that brought us home can't hit the ad
        main.postDelayed({
            try {
                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() { interstitial = null; preload() }
                    override fun onAdFailedToShowFullScreenContent(e: com.google.android.gms.ads.AdError) { interstitial = null; preload() }
                }
                gamesSinceAd = 0
                lastShown = System.currentTimeMillis()
                ad.show(activity)
            } catch (_: Throwable) { }
        }, 400)
    }
}

/** Adaptive banner. Collapses to 1dp until an ad is loaded (so offline play has no blank space). */
@Composable
fun BannerAd(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val widthDp = LocalConfiguration.current.screenWidthDp.coerceAtMost(728)
    var loaded by remember { mutableStateOf(false) }
    val adView = remember {
        AdView(ctx).apply {
            setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(ctx, widthDp))
            adUnitId = Ads.bannerId(ctx)
            adListener = object : AdListener() {
                override fun onAdLoaded() { loaded = true }
                override fun onAdFailedToLoad(error: LoadAdError) { loaded = false }
            }
            try { loadAd(AdRequest.Builder().build()) } catch (_: Throwable) { }
        }
    }
    DisposableEffect(Unit) { onDispose { adView.destroy() } }
    AndroidView(
        factory = { adView },
        modifier = modifier.fillMaxWidth().then(if (loaded) Modifier.wrapContentHeight() else Modifier.height(1.dp)),
    )
}
