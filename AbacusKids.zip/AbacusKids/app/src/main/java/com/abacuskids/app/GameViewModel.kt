package com.abacuskids.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.max

enum class Mode { FREE, MATH, TIME }
enum class Medal { NONE, BRONZE, SILVER, GOLD }

sealed interface Feedback {
    data object None : Feedback
    data object Correct : Feedback
    data class Wrong(val given: Int) : Feedback
}

data class GameUi(
    val mode: Mode = Mode.FREE,
    val question: Question? = null,
    val qIndex: Int = 0,
    val correct: Int = 0,
    val points: Int = 0,
    val timeLeft: Int = 60,
    val feedback: Feedback = Feedback.None,
    val attempts: Int = 0,
    val finished: Boolean = false,
    val medal: Medal = Medal.NONE,
    val newBest: Boolean = false,
)

class GameViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = PrefsRepo(app)
    val prefs: StateFlow<Prefs?> = repo.flow.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    var ui by mutableStateOf(GameUi())
        private set

    /** Number of beads pushed to the right in each of the 10 rows. */
    val beads = mutableStateListOf<Int>().apply { repeat(10) { add(0) } }

    private val gen = QuestionGenerator()
    private var timerJob: Job? = null

    init {
        viewModelScope.launch { repo.flow.collect { Sound.enabled = it.sound } }
    }

    private fun levelMax(): Int = listOf(10, 50, 100)[(prefs.value?.level ?: 0).coerceIn(0, 2)]

    fun setLevel(l: Int) = viewModelScope.launch { repo.edit { it[K.LEVEL] = l } }
    fun setLang(l: String) = viewModelScope.launch { repo.edit { it[K.LANG] = l } }
    fun setSound(on: Boolean) = viewModelScope.launch { repo.edit { it[K.SOUND] = on } }
    fun resetStats() = viewModelScope.launch { repo.resetStats() }

    fun clearBeads() { for (i in beads.indices) beads[i] = 0 }

    fun setRow(row: Int, count: Int) {
        if (row !in beads.indices || beads[row] == count) return
        beads[row] = count
        Sound.tick()
        if (ui.feedback is Feedback.Wrong) ui = ui.copy(feedback = Feedback.None)
    }

    fun start(mode: Mode) {
        timerJob?.cancel()
        clearBeads()
        ui = GameUi(mode = mode)
        if (mode != Mode.FREE) newQuestion()
        if (mode == Mode.TIME) {
            timerJob = viewModelScope.launch {
                while (ui.timeLeft > 0 && !ui.finished) {
                    delay(1000)
                    if (ui.finished) return@launch
                    ui = ui.copy(timeLeft = ui.timeLeft - 1)
                }
                finish()
            }
        }
    }

    fun exit() {
        timerJob?.cancel()
        clearBeads()
        ui = GameUi()
    }

    private fun newQuestion() {
        clearBeads()
        ui = ui.copy(
            question = gen.next(levelMax()), qIndex = ui.qIndex + 1,
            feedback = Feedback.None, attempts = 0,
        )
    }

    fun check() {
        val q = ui.question ?: return
        if (ui.finished || ui.feedback is Feedback.Correct) return
        val given = beads.sum()
        viewModelScope.launch { repo.edit { it.inc(K.CHECKS) } }
        if (given == q.answer) {
            Sound.correct()
            ui = ui.copy(correct = ui.correct + 1, points = ui.points + 10, feedback = Feedback.Correct)
            viewModelScope.launch { repo.edit { it.inc(K.CORRECT); it.inc(K.POINTS, 10) } }
            if (ui.mode == Mode.TIME) {
                viewModelScope.launch {
                    delay(1100)
                    if (!ui.finished && ui.question === q) next()
                }
            }
        } else {
            Sound.wrong()
            ui = ui.copy(feedback = Feedback.Wrong(given), attempts = ui.attempts + 1)
        }
    }

    fun next() {
        if (ui.finished) return
        if (ui.mode == Mode.MATH && ui.qIndex >= 10) finish() else newQuestion()
    }

    private fun medalFor(mode: Mode, score: Int): Medal = when (mode) {
        Mode.MATH -> when { score >= 9 -> Medal.GOLD; score >= 7 -> Medal.SILVER; score >= 5 -> Medal.BRONZE; else -> Medal.NONE }
        Mode.TIME -> when { score >= 10 -> Medal.GOLD; score >= 6 -> Medal.SILVER; score >= 3 -> Medal.BRONZE; else -> Medal.NONE }
        Mode.FREE -> Medal.NONE
    }

    private fun finish() {
        timerJob?.cancel()
        val u = ui
        if (u.finished || u.mode == Mode.FREE) return
        val score = u.correct
        val medal = medalFor(u.mode, score)
        val oldBest = prefs.value?.let { if (u.mode == Mode.MATH) it.bestMath else it.bestTime } ?: 0
        ui = u.copy(finished = true, medal = medal, newBest = score > oldBest)
        Sound.fanfare()
        viewModelScope.launch {
            repo.edit {
                it.inc(K.GAMES)
                val key = if (u.mode == Mode.MATH) K.BEST_MATH else K.BEST_TIME
                it[key] = max(it[key] ?: 0, score)
                when (medal) {
                    Medal.GOLD -> it.inc(K.GOLD)
                    Medal.SILVER -> it.inc(K.SILVER)
                    Medal.BRONZE -> it.inc(K.BRONZE)
                    Medal.NONE -> {}
                }
            }
        }
    }
}
