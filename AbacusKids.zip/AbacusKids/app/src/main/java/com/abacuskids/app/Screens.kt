package com.abacuskids.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class Screen { HOME, PLAY, STATS, SETTINGS }

fun Color.darken(f: Float = 0.75f) = Color(red * f, green * f, blue * f, alpha)

@Composable
fun App(vm: GameViewModel) {
    val prefs by vm.prefs.collectAsState()
    val p = prefs ?: return
    val s = if (p.lang == "ar") AR else FR
    val dir = if (p.lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr
    var screen by remember { mutableStateOf(Screen.HOME) }

    BackHandler(enabled = screen != Screen.HOME) {
        if (screen == Screen.PLAY) vm.exit()
        screen = Screen.HOME
    }

    CompositionLocalProvider(LocalS provides s, LocalLayoutDirection provides dir) {
        MaterialTheme {
            Box(
                Modifier.fillMaxSize()
                    .background(Brush.verticalGradient(listOf(C.Sky1, C.Sky2)))
            ) {
                when (screen) {
                    Screen.HOME -> HomeScreen(vm, p,
                        onPlay = { vm.start(it); screen = Screen.PLAY },
                        onStats = { screen = Screen.STATS },
                        onSettings = { screen = Screen.SETTINGS })
                    Screen.PLAY -> PlayScreen(vm, p) { vm.exit(); screen = Screen.HOME }
                    Screen.STATS -> StatsScreen(vm, p) { screen = Screen.HOME }
                    Screen.SETTINGS -> SettingsScreen(vm, p) { screen = Screen.HOME }
                }
            }
        }
    }
}

// ---------- shared widgets ----------

@Composable
fun Chunky(
    color: Color, modifier: Modifier = Modifier, enabled: Boolean = true,
    onClick: () -> Unit, content: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(22.dp)
    val c = if (enabled) color else Color(0xFFBDBDBD)
    Box(modifier.clip(shape).background(c.darken()).padding(bottom = 5.dp)) {
        Box(
            Modifier.fillMaxWidth().clip(shape).background(c)
                .clickable(enabled = enabled) { Sound.click(); onClick() }
                .padding(horizontal = 14.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center,
            content = content,
        )
    }
}

@Composable
fun BigButton(
    text: String, color: Color, modifier: Modifier = Modifier, enabled: Boolean = true,
    fontSize: TextUnit = 20.sp, onClick: () -> Unit,
) {
    Chunky(color, modifier, enabled, onClick) {
        Text(text, color = Color.White, fontSize = fontSize, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
    }
}

@Composable
fun RoundBackButton(onClick: () -> Unit) {
    Chunky(C.Orange, onClick = onClick) { Text("🏠", fontSize = 22.sp) }
}

// ---------- Home ----------

@Composable
fun HomeScreen(vm: GameViewModel, p: Prefs, onPlay: (Mode) -> Unit, onStats: () -> Unit, onSettings: () -> Unit) {
    val s = LocalS.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(Modifier.widthIn(max = 520.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Mascot()
            Text(
                if (p.lang == "ar") "المعداد السحري" else "Abaque Magique",
                fontSize = 36.sp, fontWeight = FontWeight.Black, color = C.Wood, textAlign = TextAlign.Center,
            )
            Text(s.tagline, fontSize = 16.sp, color = C.Ink, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            Text(s.level, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = C.Ink)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(s.beginner, s.intermediate, s.advanced).forEachIndexed { i, label ->
                    val sel = p.level == i
                    val col = listOf(C.Green, C.Blue, C.Red)[i]
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                            .background(if (sel) col else Color.White)
                            .border(BorderStroke(3.dp, col), RoundedCornerShape(16.dp))
                            .clickable { Sound.click(); vm.setLevel(i) }
                            .padding(vertical = 12.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                            color = if (sel) Color.White else col.darken(), textAlign = TextAlign.Center)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            ModeCard("🧮", s.freePlay, s.freePlayDesc, C.Green) { onPlay(Mode.FREE) }
            Spacer(Modifier.height(10.dp))
            ModeCard("🧠", s.mathChallenge, s.mathDesc, C.Blue) { onPlay(Mode.MATH) }
            Spacer(Modifier.height(10.dp))
            ModeCard("⏱️", s.timeChallenge, s.timeDesc, C.Red) { onPlay(Mode.TIME) }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton("📊 ${s.stats}", C.Purple, Modifier.weight(1f), fontSize = 16.sp, onClick = onStats)
                BigButton("⚙️ ${s.settings}", C.Orange, Modifier.weight(1f), fontSize = 16.sp, onClick = onSettings)
            }
            Spacer(Modifier.height(10.dp))
            Text("⭐ ${p.points}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = C.Wood)
        }
    }
}

@Composable
fun ModeCard(emoji: String, title: String, desc: String, color: Color, onClick: () -> Unit) {
    Chunky(color, Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 40.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text(desc, color = Color.White.copy(alpha = 0.92f), fontSize = 14.sp)
            }
        }
    }
}

// ---------- Play ----------

fun hintText(s: S, q: Question, given: Int, attempts: Int): String {
    val dir = if (given > q.answer) s.tooMany else s.tooFew
    val n = q.nums
    val h = when (q.kind) {
        QKind.ADD -> s.hintAdd(n[0], n[1])
        QKind.SUB -> s.hintSub(n[0], n[1])
        QKind.ADD3 -> s.hintAdd3(n[0], n[1], n[2])
        QKind.MISS_ADD -> s.hintMissAdd(n[0], n[1])
        QKind.MISS_SUB -> s.hintMissSub(n[0], n[1])
    }
    val reveal = if (attempts >= 3) "\n" + s.answerIs(q.answer) else ""
    return "$dir\n$h$reveal"
}

@Composable
fun PlayScreen(vm: GameViewModel, p: Prefs, onHome: () -> Unit) {
    val ui = vm.ui
    if (ui.finished) { ResultScreen(vm, onHome); return }
    val s = LocalS.current
    val total = vm.beads.sum()

    BoxWithConstraints(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        val landscape = maxWidth > maxHeight
        val compact = maxHeight < 560.dp

        val topBar: @Composable () -> Unit = {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                RoundBackButton(onHome)
                Spacer(Modifier.weight(1f))
                val center = when (ui.mode) {
                    Mode.FREE -> s.freePlay
                    Mode.MATH -> s.questionOf(ui.qIndex, 10)
                    Mode.TIME -> "⏱ ${ui.timeLeft}s"
                }
                Text(center, fontSize = 22.sp, fontWeight = FontWeight.Black, color = C.Wood)
                Spacer(Modifier.weight(1f))
                if (ui.mode != Mode.FREE) Text("⭐ ${ui.points}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = C.Wood)
                else Spacer(Modifier.width(48.dp))
            }
        }

        val questionCard: @Composable () -> Unit = {
            val shape = RoundedCornerShape(24.dp)
            Box(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp).clip(shape).background(Color.White)
                    .border(4.dp, C.Orange, shape).padding(if (compact) 6.dp else 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                if (ui.mode == Mode.FREE) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(s.freeTip, fontSize = 14.sp, color = C.Ink, textAlign = TextAlign.Center)
                        Text("$total", fontSize = if (compact) 36.sp else 52.sp, fontWeight = FontWeight.Black, color = C.Blue)
                    }
                } else {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text(ui.question?.text ?: "", fontSize = if (compact) 34.sp else 46.sp,
                            fontWeight = FontWeight.Black, color = C.Ink, textAlign = TextAlign.Center)
                    }
                }
            }
        }

        val feedback: @Composable () -> Unit = {
            Box(Modifier.fillMaxWidth().padding(horizontal = 8.dp).heightIn(min = 56.dp), contentAlignment = Alignment.Center) {
                when (val f = ui.feedback) {
                    is Feedback.Correct -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StarIcon(30.dp); StarIcon(38.dp); StarIcon(30.dp)
                        Text(s.cheers[ui.correct % s.cheers.size], fontSize = 18.sp, fontWeight = FontWeight.Black, color = C.Green.darken())
                    }
                    is Feedback.Wrong -> {
                        val q = ui.question
                        if (q != null) Box(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFFFFF3E0))
                                .border(2.dp, C.Orange, RoundedCornerShape(16.dp)).padding(8.dp)
                        ) {
                            Text("💡 " + hintText(s, q, f.given, ui.attempts), fontSize = 15.sp, color = C.Ink)
                        }
                    }
                    else -> if (ui.mode != Mode.FREE) Text("${s.onAbacus} : $total", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = C.Blue.darken())
                }
            }
        }

        val controls: @Composable () -> Unit = {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("🗑 ${s.clear}", C.Blue, Modifier.weight(if (ui.mode == Mode.FREE) 1f else 0.8f), fontSize = 16.sp) { vm.clearBeads() }
                if (ui.mode != Mode.FREE) {
                    BigButton(s.check, C.Green, Modifier.weight(1.2f), enabled = ui.feedback !is Feedback.Correct, fontSize = 16.sp) { vm.check() }
                    val last = ui.mode == Mode.MATH && ui.qIndex >= 10
                    BigButton(
                        if (last) s.finish else s.next, C.Purple, Modifier.weight(1.2f),
                        enabled = ui.mode == Mode.TIME || ui.feedback is Feedback.Correct, fontSize = 16.sp,
                    ) { vm.next() }
                }
            }
        }

        val abacus: @Composable (Modifier) -> Unit = { m ->
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Abacus(vm.beads, { r, c -> vm.setRow(r, c) }, m.padding(8.dp))
            }
        }

        if (landscape) {
            Column(Modifier.fillMaxSize()) {
                topBar()
                Row(Modifier.fillMaxSize()) {
                    abacus(Modifier.weight(1.5f).fillMaxHeight())
                    Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.Center) {
                        questionCard(); feedback(); controls()
                    }
                }
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                topBar(); questionCard(); feedback()
                abacus(Modifier.weight(1f).fillMaxWidth().widthIn(max = 700.dp).align(Alignment.CenterHorizontally))
                controls()
            }
        }
        if (ui.feedback is Feedback.Correct) Confetti()
    }
}

// ---------- Result ----------

@Composable
fun ResultScreen(vm: GameViewModel, onHome: () -> Unit) {
    val s = LocalS.current
    val ui = vm.ui
    val medalEmoji = when (ui.medal) { Medal.GOLD -> "🥇"; Medal.SILVER -> "🥈"; Medal.BRONZE -> "🥉"; Medal.NONE -> "🎈" }
    val medalName = when (ui.medal) { Medal.GOLD -> s.gold; Medal.SILVER -> s.silver; Medal.BRONZE -> s.bronze; Medal.NONE -> s.keepGoing }
    val stars = when (ui.medal) { Medal.GOLD -> 3; Medal.SILVER -> 2; else -> 1 }
    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
        ) {
            Text(if (ui.mode == Mode.TIME) s.timeUp else s.resultTitle, fontSize = 34.sp, fontWeight = FontWeight.Black, color = C.Wood)
            Text(medalEmoji, fontSize = 96.sp)
            Text(medalName, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = C.Ink, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                repeat(3) { i -> StarIcon(if (i == 1) 64.dp else 52.dp, if (i < stars) C.Yellow else Color(0xFFCFD8DC)) }
            }
            Spacer(Modifier.height(10.dp))
            Text(if (ui.mode == Mode.MATH) s.scoreOutOf(ui.correct) else s.correctCount(ui.correct),
                fontSize = 28.sp, fontWeight = FontWeight.Black, color = C.Blue.darken())
            Text(s.pointsEarned(ui.points), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = C.Green.darken())
            if (ui.newBest) Text(s.newBest, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = C.Red)
            Spacer(Modifier.height(18.dp))
            Column(Modifier.widthIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton("🔁 ${s.playAgain}", C.Green, Modifier.fillMaxWidth()) { vm.start(ui.mode) }
                BigButton("🏠 ${s.home}", C.Orange, Modifier.fillMaxWidth(), onClick = onHome)
            }
        }
        Confetti()
    }
}

// ---------- Parent stats ----------

@Composable
fun StatsScreen(vm: GameViewModel, p: Prefs, onBack: () -> Unit) {
    val s = LocalS.current
    var confirm by remember { mutableStateOf(false) }
    val acc = if (p.checks > 0) (100 * p.correct / p.checks) else 0
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(Modifier.widthIn(max = 520.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RoundBackButton(onBack)
                Spacer(Modifier.width(12.dp))
                Text("📊 ${s.parents}", fontSize = 26.sp, fontWeight = FontWeight.Black, color = C.Wood)
            }
            StatRow("🎮", s.gamesPlayed, "${p.games}", C.Blue)
            StatRow("✅", s.totalCorrect, "${p.correct}", C.Green)
            StatRow("🎯", s.accuracy, "$acc%", C.Orange)
            StatRow("🧠", s.bestMath, "${p.bestMath} / 10", C.Purple)
            StatRow("⏱️", s.bestTime, "${p.bestTime}", C.Red)
            StatRow("⭐", s.totalPoints, "${p.points}", C.Yellow.darken(0.85f))
            StatRow("🏅", s.medals, "🥇 ${p.gold}   🥈 ${p.silver}   🥉 ${p.bronze}", C.Wood)
            Spacer(Modifier.height(8.dp))
            BigButton(s.resetStats, C.Red, Modifier.fillMaxWidth(), fontSize = 16.sp) { confirm = true }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(s.resetStats) },
            text = { Text(s.resetConfirm) },
            confirmButton = { TextButton({ vm.resetStats(); confirm = false }) { Text(s.yes, fontSize = 18.sp) } },
            dismissButton = { TextButton({ confirm = false }) { Text(s.no, fontSize = 18.sp) } },
        )
    }
}

@Composable
fun StatRow(emoji: String, label: String, value: String, color: Color) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Color.White).border(3.dp, color, shape).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(emoji, fontSize = 28.sp)
        Spacer(Modifier.width(10.dp))
        Text(label, Modifier.weight(1f), fontSize = 15.sp, color = C.Ink, fontWeight = FontWeight.SemiBold)
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Black, color = color.darken(0.9f))
    }
}

// ---------- Settings ----------

@Composable
fun SettingsScreen(vm: GameViewModel, p: Prefs, onBack: () -> Unit) {
    val s = LocalS.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(Modifier.widthIn(max = 520.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RoundBackButton(onBack)
                Spacer(Modifier.width(12.dp))
                Text("⚙️ ${s.settings}", fontSize = 26.sp, fontWeight = FontWeight.Black, color = C.Wood)
            }
            Text("🌍 ${s.language}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = C.Ink)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton("Français", if (p.lang == "fr") C.Blue else Color(0xFF90A4AE), Modifier.weight(1f)) { vm.setLang("fr") }
                BigButton("العربية", if (p.lang == "ar") C.Blue else Color(0xFF90A4AE), Modifier.weight(1f)) { vm.setLang("ar") }
            }
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("🔊 ${s.sound}", Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = C.Ink)
                Switch(checked = p.sound, onCheckedChange = { vm.setSound(it) })
            }
            Text(s.about, fontSize = 14.sp, color = C.Ink, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}
